#include <iostream>
#include <conio.h>

#include "Graphics.hh"

int main()
{
    MYTH::GRAPHICS graphics;
    MYTH::TEXTBOX textbox;

    MYTH::FUNCTIONS::clearConsole();

    textbox.border_auto = true;
    textbox.border_color = RED;
    textbox.x = 20;
    textbox.y = 5;
    

    textbox.text = "rei femboy";
    textbox.text_color = BLUE;

    graphics.print_Textbox(textbox);

    return 0;
}